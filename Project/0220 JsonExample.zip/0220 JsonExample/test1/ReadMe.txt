﻿JsonConvert

For simple scenarios where you want to 
convert to and from a JSON string, the 
SerializeObject() and DeserializeObject() 
methods on JsonConvert provide an easy-to-use 
wrapper over JsonSerializer.