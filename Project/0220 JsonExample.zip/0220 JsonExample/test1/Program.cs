﻿using Newtonsoft.Json;
using System;

namespace test1
{
    class Program
    {
        // Clase for object to be serialized
        public class Product
        {
            public string Name { get; set; }
            public DateTime ExpiryDate { get; set; }
            public decimal Price { get; set; }
            public string[] Sizes { get; set; }
        }
        static void Main(string[] args)
        {
            // Create an Object
            Product product = new Product();
            // Set some properties
            product.Name = "Apple";
            product.ExpiryDate = new DateTime(2008, 12, 28);
            product.Price = 3.99M;
            product.Sizes = new string[] { "Small", "Medium", "Large" };
            // Serializing
            string json = JsonConvert.SerializeObject(product);
            // Deserilizing
            Product dp = JsonConvert.DeserializeObject<Product>(json);
        }
    }
}
//{
//  "Name": "Apple",
//  "ExpiryDate": "2008-12-28T00:00:00",
//  "Price": 3.99,
//  "Sizes": [
//    "Small",
//    "Medium",
//    "Large"
//  ]
//}