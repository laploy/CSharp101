﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace _010_JsonLINQ
{
    class Program
    {
        static void Main(string[] args)
        {
            JObject myObj = JObject.Parse(@"{
              'CPU': 'Intel',
              'Drives': [
                'DVD read/writer',
                '500 gigabyte hard drive'
              ]
            }");

            string cpu = (string)myObj["CPU"];
            // Intel

            string firstDrive = (string)myObj["Drives"][0];
            // DVD read/writer

            IList<string> allDrives = myObj["Drives"].Select(t => (string)t).ToList();
            foreach (var v in allDrives)
                Console.WriteLine(v);
            // DVD read/writer
            // 500 gigabyte hard drive
        }
    }
}
