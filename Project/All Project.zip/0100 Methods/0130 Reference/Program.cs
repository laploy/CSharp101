﻿using System;

namespace _0130_Reference
{
    class Program
    {
        static void test(string s, ref string a)
        {
            s = "abc";
            a = "def";
        }
        static void Main(string[] args)
        {
            String s = "hello";
            String a = "world";
            test(s, ref a);
            Console.WriteLine(s);   // hello
            Console.WriteLine(a);   // def
        }
    }
}
