﻿using System;

namespace _0120_Invoke
{
    class Program
    {
        static double GetRectangleArea(double width, double height)
        {
            double area = width * height;
            return area;
        }
        static void Main(string[] args)
        {
            double myArea = GetRectangleArea(5, 2);
            Console.WriteLine(myArea);
        }
    }
}
