﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _002_List
{
    class Program
    {
        static void Main(string[] args)
        {
            // declear list
            List<int> list = new List<int>();
            // add item to list
            list.Add(2);
            list.Add(3);
            list.Add(7);
            // Loop through List with foreach.
            foreach (int prime in list)
            {
                System.Console.WriteLine(prime);
            }

            // insert item to list
            List<string> dogs = new List<string>(); // Example list.
            dogs.Add("spaniel"); // Contains: spaniel.
            dogs.Add("beagle"); // Contains: spaniel, beagle.
            dogs.Insert(1, "dalmatian"); // Spaniel, dalmatian, beagle.
            // remove item from list
            dogs.RemoveAt(1); // // Contains: spaniel, beagle.

            // sort list
            String[] names = { "Samuel", "Dakota", "Koani", "Saya", "Vanya",
                         "Yiska", "Yuma", "Jody", "Nikita" };
            var nameList = new List<String>();
            nameList.AddRange(names);
            Console.WriteLine("List in unsorted order: ");
            foreach (var name in nameList)
                Console.Write("   {0}", name);
            Console.WriteLine(Environment.NewLine);
            nameList.Sort();
            Console.WriteLine("List in sorted order: ");
            foreach (var name in nameList)
                Console.Write("   {0}", name);
            Console.WriteLine();
            // The example displays the following output:
            //    List in unsorted order:
            //       Samuel   Dakota   Koani   Saya   Vanya   Yiska   Yuma   Jody   Nikita
            //
            //    List in sorted order:
            //       Dakota   Jody   Koani   Nikita   Samuel   Saya   Vanya   Yiska   Yuma
        }
    }
}
