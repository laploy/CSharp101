﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Out.WriteLine("Hello World");
            // Print String
            Console.WriteLine("Hello World");
            // Print int
            Console.WriteLine(5);
            // Print double
            Console.WriteLine(3.14159265358979);
            // multiple line / new line
            Console.WriteLine("I love");
            Console.Write("this ");
            Console.Write("Book!");
            // String concat
            string age = "twenty six";
            string text = "He is " + age + " years old.";
            Console.WriteLine(text);
            Console.WriteLine("He is " + age + " years old.");
            string s = "Four: " + 2 + 2;
            Console.WriteLine(s);
            // Four: 22
            string s1 = "Four: " + (2 + 2);
            Console.WriteLine(s1);
            // Four: 4
        }
    }
}