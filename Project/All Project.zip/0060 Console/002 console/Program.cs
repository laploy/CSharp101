﻿using System;

namespace _002_console
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "Hello World!";
            // Print (the normal way)
            Console.Write(str);
            // Print (through formatting string)
            Console.Write("{0}", str);
            string name = "John";
            int age = 18;
            string town = "Seattle";
            Console.Write("{0} is {1} years old from {2}!\n", name, age, town);
            Console.Write("{1} is {0} years old from {3}!", 18, "John", 0, "Seattle");
            // Alignment Component
            Console.WriteLine("{0,6}", 123);
            Console.WriteLine("{0,6}", 1234);
            Console.WriteLine("{0,6}", 12);
            Console.Write("{0,-6}", 123);
            Console.WriteLine("--end");
        }
    }
}