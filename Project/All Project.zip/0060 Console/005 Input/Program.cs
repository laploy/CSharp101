﻿using System;

namespace _005_Input
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Please enter your first name: ");
            string firstName = Console.ReadLine();
            Console.Write("Please enter your last name: ");
            string lastName = Console.ReadLine();
            Console.WriteLine("Hello, {0} {1}!", firstName, lastName);
            // Output: Please enter your first name: John
            // Please enter your last name: Smith
            // Hello, John Smith!

            // using read()
            int codeRead = 0;
            do
            {
                codeRead = Console.Read();
                if (codeRead != 0)
                {
                    Console.Write((char)codeRead);
                }
            }
            while (codeRead != 10);

            // reading number
            Console.Write("a = ");
            int a = int.Parse(Console.ReadLine());
            Console.Write("b = ");
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine("{0} + {1} = {2}", a, b, a + b);
            Console.WriteLine("{0} * {1} = {2}", a, b, a * b);
            Console.Write("f = ");
            double f = double.Parse(Console.ReadLine());
            Console.WriteLine("{0} * {1} / {2} = {3}",a, b, f, a * b / f);
            //a = 5
            //b = 6
            //5 + 6 = 11
            //5 * 6 = 30
            //f = 7.5
            //5 * 6 / 7.5 = 4

            // pars string to double
            Console.Write("Enter a floating-point number: ");
            string line = Console.ReadLine();
            double number = double.Parse(line);
            Console.WriteLine("You entered: {0}", number);
            // Parsing Numbers Conditionally
            string str = Console.ReadLine();
            int intValue;
            bool parseSuccess = Int32.TryParse(str, out intValue);
            Console.WriteLine(parseSuccess ?
            "The square of the number is " + intValue * intValue + "."
            : "Invalid number!");

            // Reading by Console.ReadKey()
            ConsoleKeyInfo key = Console.ReadKey();
            Console.WriteLine();
            Console.WriteLine("Character entered: " + key.KeyChar);
            Console.WriteLine("Special keys: " + key.Modifiers);
            //A
            //Character entered: A
            //Special keys: Shift
        }
    }
}