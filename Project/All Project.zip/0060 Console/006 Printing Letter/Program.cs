﻿using System;

namespace _006_Printing_Letter
{
    class Program
    {
        static void Main(string[] args)
        {
            // print out letter from book publisher to reader
            Console.Write("Enter person name: ");
            string person = Console.ReadLine();
            Console.Write("Enter book name: ");
            string book = Console.ReadLine();
            string from = "Authors Team";
            Console.WriteLine(" Dear {0},", person);
            Console.Write("We are pleased to inform " +
            "you that \"{1}\" is the best Bulgarian book. {2}" +
            "The authors of the book wish you good luck {0}!{2}",
            person, book, Environment.NewLine);
            Console.WriteLine(" Yours,");
            Console.WriteLine(" {0}", from);
            //Enter person name: Readers
            //Enter book name: Introduction to programming with C#
            //Dear Readers,
            //We are pleased to inform you that "Introduction to programming
            //with C#" is the best Bulgarian book.
            //The authors of the book wish you good luck Readers!
            //Yours,
            //Authors Team
        }
    }
}