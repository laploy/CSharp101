﻿using System;

namespace _002_if_statement
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter two numbers.");
            Console.Write("Enter first number: ");
            int firstNumber = int.Parse(Console.ReadLine());
            Console.Write("Enter second number: ");
            int secondNumber = int.Parse(Console.ReadLine());
            int biggerNumber = firstNumber;
            if (secondNumber > firstNumber)
            {
                biggerNumber = secondNumber;
            }
            Console.WriteLine("The bigger number is: {0}", biggerNumber);
            //Enter two numbers.
            //Enter first number: 4
            //Enter second number: 5
            //The bigger number is: 5

            int a = 6;
            if (a > 5)
                Console.WriteLine("The variable is greater than 5.");
                Console.WriteLine("This code will always execute!");
            // Bad practice: misleading code
        }
    }
}