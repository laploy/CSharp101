﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            // Comparison operators
            int weight = 700;
            Console.WriteLine(weight >= 500); // True
            char gender = 'm';
            Console.WriteLine(gender <= 'f'); // False
            double colorWaveLength = 1.630;
            Console.WriteLine(colorWaveLength > 1.621); // True
            int a = 5;
            int b = 7;
            bool condition = (b > a) && (a + b < a * b);
            Console.WriteLine(condition); // True
            Console.WriteLine('B' == 'A' + 1); // True

            // Comparison of Integers and Characters
            Console.WriteLine("char 'a' == 'a'? " + ('a' == 'a')); // True
            Console.WriteLine("char 'a' == 'b'? " + ('a' == 'b')); // False
            Console.WriteLine("5 != 6? " + (5 != 6)); // True
            Console.WriteLine("5.0 == 5L? " + (5.0 == 5L)); // True
            Console.WriteLine("true == false? " + (true == false)); // False

            // Comparison of References to Objects
            string str = "beer";
            string anotherStr = str;
            string thirdStr = "bee";
            thirdStr = thirdStr + 'r';
            Console.WriteLine("str = {0}", str);
            Console.WriteLine("anotherStr = {0}", anotherStr);
            Console.WriteLine("thirdStr = {0}", thirdStr);
            Console.WriteLine(str == anotherStr); // True - same object
            Console.WriteLine(str == thirdStr); // True - equal objects
            Console.WriteLine((object)str == (object)anotherStr); // True
            Console.WriteLine((object)str == (object)thirdStr); // False

            // Logical Operators
            bool result1 = (2 < 3) && (3 < 4);   // True
            bool result2 = (2 < 3) || (1 == 2);  // True
            Console.WriteLine("Exclusive OR: " + ((2 < 3) ^ (4 > 3)));
            // Exclusive OR: False
            bool value = !(7 == 5); // True
            Console.WriteLine(value);
        }
    }
}