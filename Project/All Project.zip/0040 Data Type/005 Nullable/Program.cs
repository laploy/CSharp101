﻿using System;

namespace _005_Nullable
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 5;
            int? ni = i;
            Console.WriteLine(ni); // 5

            // i = ni; // this will fail to compile 
            Console.WriteLine(ni.HasValue); // True 
            i = ni.Value;
            Console.WriteLine(i); // 5

            ni = null;
            Console.WriteLine(ni.HasValue); // False 
            //i = ni.Value; // System.InvalidOperationException 
            i = ni.GetValueOrDefault();
            Console.WriteLine(i); // 0
            Console.Read();
        }
    }
}