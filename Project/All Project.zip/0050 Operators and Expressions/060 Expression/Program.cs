﻿using System;

namespace _060_Expression
{
    class Program
    {
        static void Main(string[] args)
        {
            int r = (150 - 20) / 2 + 5;
            // Expression for calculating the surface of the circle 
            double surface = Math.PI * r * r;
            // Expression for calculating the perimeter of the circle 
            double perimeter = 2 * Math.PI * r;
            Console.WriteLine(r);
            Console.WriteLine(surface);
            Console.WriteLine(perimeter);
            // use bracket to make the code clear
            double incorrect = (double)((1 + 2) / 4);
            Console.WriteLine(incorrect); // 0

            double correct = ((double)(1 + 2)) / 4;
            Console.WriteLine(correct); // 0.75

            Console.WriteLine("2 + 3 = " + 2 + 3); // 2 + 3 = 23 
            Console.WriteLine("2 + 3 = " + (2 + 3)); // 2 + 3 = 5

        }
    }
}