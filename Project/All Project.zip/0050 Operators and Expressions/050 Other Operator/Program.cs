﻿using System;

namespace _050_Other_Operator
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 6; int b = 3;
            Console.WriteLine(a + b / 2); // 7 
            Console.WriteLine((a + b) / 2); // 4 
            string s = "Beer";
            Console.WriteLine(s is string); // True 
            string notNullString = s;
            string nullString = null;
            Console.WriteLine(nullString ?? "Unspecified"); // Unspecified 
            Console.WriteLine(notNullString ?? "Specified"); // Beer
        }
    }
}