﻿using System;

namespace _020_Logical
{
    class Program
    {
        static void Main(string[] args)
        {
            bool a = true;
            bool b = false;
            Console.WriteLine(a && b); // False
            Console.WriteLine(a || b); // True
            Console.WriteLine(!b); // True
            Console.WriteLine(b || true); // True
            Console.WriteLine((5 > 7) ^ (a == b)); // False
        }
    }
}