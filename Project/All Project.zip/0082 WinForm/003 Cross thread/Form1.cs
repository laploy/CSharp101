﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _003_Cross_thread
{
    public partial class Form1 : Form
    {
        Timer myTimer;
        public Form1()
        {
            InitializeComponent();
            myTimer = new Timer();
            myTimer.Interval = 500;
            myTimer.Tick += MyTimer_Tick;
            myTimer.Start();
        }
        private void MyTimer_Tick(object sender, EventArgs e)
        {
            DateTime myNow = DateTime.Now;
            string myTime = 
                myNow.Hour.ToString("00") + ":" +
                myNow.Minute.ToString("00") + ":" +
                myNow.Second.ToString("00");

            label1.Invoke(new MethodInvoker(delegate {
                label1.Text = myTime; }));
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
