﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _002_Controls
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            comboBox1.Items.Add("Bangkok");
            comboBox1.Items.Add("Tokyo");
            comboBox1.Items.Add("New York");
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedIndex = comboBox1.SelectedIndex;
            Object selectedItem = comboBox1.SelectedItem;
            string s = "Selected Item Text: " + selectedItem.ToString() + "\r\n" +
                            "Index: " + selectedIndex.ToString();
            textBoxMain.Text = s;
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
                textBoxMain.Text = "checkBox1 Chekced";
            else
                textBoxMain.Text = "checkBox1 unChekced";
        }
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if(radioButton1.Checked) textBoxMain.Text = "radioButton1 Chekced";
        }
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked) textBoxMain.Text = "radioButton2 Chekced";
        }
        private void buttonHello_Click(object sender, EventArgs e)
        {
            textBoxMain.Text = "Hello, World!";
        }
        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxMain.Clear();
        }
    }
}
