﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UCLib1
{
    public partial class MachineUC1 : UserControl
    {

        public MachineUC1()
        {
            InitializeComponent();
        }
        public void SetColor(Color c)
        {
            this.BackColor = c;
        }

        private void buttonRun_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.LightSeaGreen;
        }

        private void buttonStop_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.LightGray;
        }
    }
}
