﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Loy.Example.Machine;

namespace ConsoleApp1
{
    class Program
    {
        static Machine001[] myArray = new Machine001[3];
        static void Main(string[] args)
        {
            CreatObjects();
            ViewObject();
        }
        static void CreatObjects()
        {
            Machine001 myMachine1 = new Machine001();
            myMachine1.Id = 1;
            myMachine1.Name = "MC1";
            myMachine1.Type = mType.inspec;
            myMachine1.Run();

            Machine001 myMachine2 = new Machine001
            {
                Id = 2,
                Name = "Bravo",
                Type = mType.asm
            };  // object initializer
            myMachine2.Stop();

            Machine001 myMachine3 = new Machine001();
            myMachine3.Id = 3;
            myMachine3.Name = "Alpha";
            myMachine3.Type = mType.packing;
            myMachine3.Run();

            myArray[0] = myMachine1;
            myArray[1] = myMachine2;
            myArray[2] = myMachine3;
        }
        static void ViewObject()
        {
            foreach (var v in myArray)
            {
                Console.WriteLine("ID : " + v.Id);
                Console.WriteLine("Name : " + v.Name);
                Console.WriteLine("Type : " + v.Type);
                Console.WriteLine("Status : " + v.Status);
                Console.WriteLine("- - - - - - - -");
            }
        }
    }
}
