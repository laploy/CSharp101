﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loy.Example.Machine
{
    public enum mType { inspec, asm, packing, welding };
    public enum mStat { run, stop };

    public class Machine001
    {
        // field members
        private int id;
        private string name;
        private mType type;
        private mStat status;
        // properties
        public int Id { get => id; set => id = value; }
        public string Name { get => name; set => name = value; }
        public mType Type { get => type; set => type = value; }
        public mStat Status { get => status; set => status = value; }

        // default constructor
        public Machine001() { }
        // Methods
        public void Run()
        {
            Console.WriteLine("Running");
            status = mStat.run;
        }
        public void Stop()
        {
            Console.WriteLine("Stoping");
            status = mStat.stop;
        }
    }
}
