﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Loy.Example.Machine;

namespace WinTest001
{
    public partial class Form1 : Form
    {
        private UCLib1.MachineUC1 machineUC11 = new UCLib1.MachineUC1();
        private UCLib1.MachineUC1 machineUC12 = new UCLib1.MachineUC1();
        private Machine001 myMachine1 = new Machine001();
        private Machine001 myMachine2 = new Machine001();
        private Timer myTimer = new Timer();
        private bool flag = false;

        public Form1()
        {
            InitializeComponent();
            CreateMachine();
            CreateUC();
            SetUCProperties();
            myTimer.Interval = 2500;
            myTimer.Enabled = true;
            myTimer.Tick += MyTimer_Tick;
        }

        private void MyTimer_Tick(object sender, EventArgs e)
        {
            if(flag)
                machineUC12.SetColor(Color.LightGray);
            else
                machineUC12.SetColor(Color.LightSeaGreen);
            flag = !flag;
        }

        private void SetUCProperties()
        {
            machineUC11.labelId.Text = myMachine1.Id.ToString();
            machineUC11.labelName.Text = myMachine1.Name;
            machineUC11.labelType.Text = myMachine1.Type.ToString();
            if (myMachine1.Status == mStat.stop)
                machineUC11.SetColor(Color.LightGray);
            else
                machineUC11.SetColor(Color.LightSeaGreen);

            machineUC12.labelId.Text = myMachine2.Id.ToString();
            machineUC12.labelName.Text = myMachine2.Name;
            machineUC12.labelType.Text = myMachine2.Type.ToString();
            if (myMachine2.Status == mStat.stop)
                machineUC12.SetColor(Color.LightGray);
            else
                machineUC12.SetColor(Color.LightSeaGreen);
        }
        private void CreateUC()
        {
            this.machineUC11.Location = new System.Drawing.Point(13, 13);
            this.machineUC11.Name = "machineUC11";
            this.machineUC11.Size = new System.Drawing.Size(153, 118);
            this.Controls.Add(this.machineUC11);

            int top = 13;
            int left = machineUC11.Left + machineUC11.Width + 10;
            this.machineUC12.Top = top;
            this.machineUC12.Left = left;
            this.machineUC12.Name = "machineUC11";
            this.machineUC12.Size = new System.Drawing.Size(153, 118);
            this.Controls.Add(this.machineUC12);
        }
        private void CreateMachine()
        {
            myMachine1.Id = 1;
            myMachine1.Name = "MC1";
            myMachine1.Type = mType.inspec;
            myMachine1.Status = mStat.stop;
            //myMachine1.Run();

            myMachine2.Id = 2;
            myMachine2.Name = "MC2";
            myMachine2.Type = mType.welding;
            myMachine2.Status = mStat.run;
            //myMachine2.Run();
        }
    }
}
